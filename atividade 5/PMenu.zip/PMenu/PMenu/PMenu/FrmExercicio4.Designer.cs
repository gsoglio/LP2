﻿namespace PMenu
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            richTxtTexto = new RichTextBox();
            btnContNum = new Button();
            btnBranco = new Button();
            btnContLetra = new Button();
            SuspendLayout();
            // 
            // richTxtTexto
            // 
            richTxtTexto.Location = new Point(122, 120);
            richTxtTexto.Margin = new Padding(3, 2, 3, 2);
            richTxtTexto.Name = "richTxtTexto";
            richTxtTexto.Size = new Size(528, 58);
            richTxtTexto.TabIndex = 0;
            richTxtTexto.Text = "";
            // 
            // btnContNum
            // 
            btnContNum.BackColor = Color.FromArgb(255, 192, 192);
            btnContNum.Location = new Point(122, 212);
            btnContNum.Margin = new Padding(3, 2, 3, 2);
            btnContNum.Name = "btnContNum";
            btnContNum.Size = new Size(137, 50);
            btnContNum.TabIndex = 1;
            btnContNum.Text = "Contagem de números";
            btnContNum.UseVisualStyleBackColor = false;
            btnContNum.Click += btnContNum_Click;
            // 
            // btnBranco
            // 
            btnBranco.BackColor = Color.FromArgb(224, 224, 224);
            btnBranco.Location = new Point(324, 212);
            btnBranco.Margin = new Padding(3, 2, 3, 2);
            btnBranco.Name = "btnBranco";
            btnBranco.Size = new Size(137, 50);
            btnBranco.TabIndex = 2;
            btnBranco.Text = "Posição caracter em branco";
            btnBranco.UseVisualStyleBackColor = false;
            btnBranco.Click += btnBranco_Click;
            // 
            // btnContLetra
            // 
            btnContLetra.BackColor = Color.FromArgb(192, 255, 192);
            btnContLetra.Location = new Point(513, 212);
            btnContLetra.Margin = new Padding(3, 2, 3, 2);
            btnContLetra.Name = "btnContLetra";
            btnContLetra.Size = new Size(137, 50);
            btnContLetra.TabIndex = 3;
            btnContLetra.Text = "Contagem de letras";
            btnContLetra.UseVisualStyleBackColor = false;
            btnContLetra.Click += btnContLetra_Click;
            // 
            // FrmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(822, 416);
            Controls.Add(btnContLetra);
            Controls.Add(btnBranco);
            Controls.Add(btnContNum);
            Controls.Add(richTxtTexto);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FrmExercicio4";
            Text = "FrmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox richTxtTexto;
        private Button btnContNum;
        private Button btnBranco;
        private Button btnContLetra;
    }
}