﻿namespace PMenu
{
    partial class FrmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            txtPrimeiroNum = new TextBox();
            txtSegundoNum = new TextBox();
            btnSorteio = new Button();
            SuspendLayout();
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNumero1.Location = new Point(82, 116);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(312, 30);
            lblNumero1.TabIndex = 0;
            lblNumero1.Text = "Digite o primeiro número inteiro";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNumero2.Location = new Point(82, 167);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(294, 30);
            lblNumero2.TabIndex = 1;
            lblNumero2.Text = "Digite o último número inteiro";
            // 
            // txtPrimeiroNum
            // 
            txtPrimeiroNum.Location = new Point(460, 116);
            txtPrimeiroNum.Margin = new Padding(3, 2, 3, 2);
            txtPrimeiroNum.Name = "txtPrimeiroNum";
            txtPrimeiroNum.Size = new Size(110, 23);
            txtPrimeiroNum.TabIndex = 2;
            txtPrimeiroNum.Validating += txtPrimeiroNum_Validating;
            // 
            // txtSegundoNum
            // 
            txtSegundoNum.Location = new Point(460, 174);
            txtSegundoNum.Margin = new Padding(3, 2, 3, 2);
            txtSegundoNum.Name = "txtSegundoNum";
            txtSegundoNum.Size = new Size(110, 23);
            txtSegundoNum.TabIndex = 3;
            txtSegundoNum.Validating += txtSegundoNum_Validating;
            // 
            // btnSorteio
            // 
            btnSorteio.BackColor = Color.FromArgb(192, 255, 192);
            btnSorteio.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSorteio.Location = new Point(306, 260);
            btnSorteio.Margin = new Padding(3, 2, 3, 2);
            btnSorteio.Name = "btnSorteio";
            btnSorteio.Size = new Size(120, 97);
            btnSorteio.TabIndex = 4;
            btnSorteio.Text = "Sortear";
            btnSorteio.UseVisualStyleBackColor = false;
            btnSorteio.Click += btnSorteio_Click;
            // 
            // FrmExercicio5
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(848, 416);
            Controls.Add(btnSorteio);
            Controls.Add(txtSegundoNum);
            Controls.Add(txtPrimeiroNum);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FrmExercicio5";
            Text = "FrmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNumero1;
        private Label lblNumero2;
        private TextBox txtPrimeiroNum;
        private TextBox txtSegundoNum;
        private Button btnSorteio;
    }
}