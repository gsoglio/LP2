﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out LadoA))
            {
                MessageBox.Show("Dado Inválido");
                txtLadoA.Focus();
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoB.Text, out LadoB))
            {
                MessageBox.Show("Dado Inválido");
                txtLadoB.Focus(); // Retorna para o usuário a caixa em branco
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoC.Text, out LadoC)) // Try Parse serve para converter texto para número
            {
                MessageBox.Show("Dado Inválido");
                txtLadoC.Focus();

            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (LadoA < (LadoB + LadoC) && LadoA > (Math.Abs(LadoB - LadoC)) &&
                LadoB < (LadoA + LadoC) && LadoB > (Math.Abs(LadoA - LadoC)) &&
                LadoC < (LadoA + LadoB) && LadoC > (Math.Abs(LadoA - LadoB)))
            {

                if ((LadoA == LadoB) && (LadoB == LadoC))
                    MessageBox.Show("Triângulo Equilátero"); //Todos os lados são iguais
                else
                {
                    if (!(LadoA == LadoB) && !(LadoB == LadoC) && !(LadoA == LadoC)) //Todos os lados são diferentes
                        MessageBox.Show("Triângulo Escaleno");
                    else
                        MessageBox.Show("Triângulo Isóceles"); //Dois Iguais e um diferente

                }

            }
            else
                MessageBox.Show("Não é um triângulo!");

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
