﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Altura, Peso, Imc; // declarando variávies globais para usar em todos os eventos

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if((!double.TryParse(mskbxPeso.Text, out Peso)) || (Peso <=0))
            {
                MessageBox.Show("Peso Inválido");
                mskbxPeso.Focus();
            }
   

        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxAltura.Text, out Altura)) || (Altura <=0))
            {
                MessageBox.Show("Altura Inválida");
                mskbxAltura.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close(); // não é possível fechar insirir nenhum dado.
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Imc = Peso / (Math.Pow(Altura, 2));
            txtImc.Text = Imc.ToString("N2"); // n2 para deixar com 2 casas decimais. 
            Imc = Math.Round(Imc, 1); // andar casas decmais
            

            if (Imc <= 18.5)
                MessageBox.Show("Classificação: Magreza ");
            else
                if (Imc <= 24.9)
                MessageBox.Show("Classificação: Normal ");
            else
                if (Imc <= 29.9)
                MessageBox.Show("Classificação: Sobrepeso ");
            else
                if (Imc <= 39.9)
                MessageBox.Show("Classificação: Obesidade ");
            else
                MessageBox.Show("Classificação: Obesidade Grave ");

        }


        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear(); //Usar clear para limpar os campos
            mskbxPeso.Clear();
            txtImc.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
