﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    abstract internal class Empregado
    {
        private int matricula; //atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula // propriedade
        {
            get { return matricula; } // puxa o valor do atributo
            set { matricula = value; } // atribui 
        }
        public string NomeEmpregado
        {
            get { return nomeEmpregado;}
            set { nomeEmpregado = value;}
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa;}
            set {  dataEntradaEmpresa = value;}
        }

        public virtual double TempoTrabalho() // virtual significa que se eu quiser alterar os metodos nas filhas da classes, ele permite. Ex: Empregado com um obj Tempo Trabalho que retorna a qtde de dias trabalhados. Se eu criar um novo obj em uma subclasse "Horista" com o mesmo nome TempoTrabalho, prevalecerá o NÃO virtual, ou seja, da subclasse. 
        {
            double diasTrabalho;
            DateTime dataAtual = DateTime.Today;
            diasTrabalho = dataAtual.Subtract(DataEntradaEmpresa).TotalDays;
            return diasTrabalho;

        }

        public abstract double SalarioBruto();

    }
}
