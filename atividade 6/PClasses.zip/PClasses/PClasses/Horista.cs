﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    internal class Horista : Empregado //herança, o horista é filho do empregado, portanto vai herdar os atributos dele.
        // Não pode herdar mais de uma classe, não há herança multipla. 

    {
        public double SalarioHora { get; set; }

        public double NumeroHora { get; set; }

        public double DiasFalta { get; set; }

        public override double TempoTrabalho()
        {
            double diasTrabalho; // virtual - quem quiser substituir por um novo TempoTrabalho, tudobem. 
            DateTime dataAtual = DateTime.Today;
            diasTrabalho = dataAtual.Subtract(DataEntradaEmpresa).TotalDays;  // se der erro por conta de tipo de acesso (public ou private), utilizar a propriedade no lugar do atributo - maiusculo
            return diasTrabalho - DiasFalta;
        }

        public override double SalarioBruto()
        {
            return SalarioHora * NumeroHora;

        }
    }
}
