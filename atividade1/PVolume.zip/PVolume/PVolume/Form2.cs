﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form2 : Form
    {

        double raio;
        double altura;
        double volume;

        public Form2()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Raio Inválido!");
                txtRaio.Focus();

            }
            else
            {
                if (raio <= 0)
                {
                    MessageBox.Show("Raio dever ser maior do que zero!");
                    txtRaio.Focus();
                }
            }
        }

        private void txtAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida!");
                e.Cancel = true;

            }
            else
            {
                if (altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior do que zero!");
                    e.Cancel = true;
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear(); //use o clear"
            txtRaio.Text = "";
            txtVolume.Text = String.Empty; // todos servem para limpar os dados.
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
        
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("n2");
            
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();

        }
    }
}
